﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace Filmek
{
    public partial class MainWindow : Window
    {
        ObservableCollection<Film> filmek = new ObservableCollection<Film>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Betoltes_Click(object sender, RoutedEventArgs e)
        {
            filmek.Clear();

            filmek.Add(new Film
            {
                Cim = "Csillagok háborúja",
                Mufaj = "sci-fi",
                Hossz = 121,
                Ertekeles = 8.6
            });

            filmek.Add(new Film
            {
                Cim = "Titanic",
                Mufaj = "dráma",
                Hossz = 195,
                Ertekeles = 7.8
            });

            filmek.Add(new Film
            {
                Cim = "A Gyűrűk Ura",
                Mufaj = "fantasy",
                Hossz = 201,
                Ertekeles = 8.8
            });

            filmek.Add(new Film
            {
                Cim = "Mátrix",
                Mufaj = "sci-fi",
                Hossz = 136,
                Ertekeles = 8.7
            });

            filmek.Add(new Film
            {
                Cim = "Shrek",
                Mufaj = "animáció",
                Hossz = 90,
                Ertekeles = 7.9
            });

            dgFilmek.ItemsSource = filmek;

            foreach (var oszlop in dgFilmek.Columns)
            {
                oszlop.Visibility = Visibility.Visible;
            }

            progressBar.Value = filmek.Count;

            CollectionViewSource.GetDefaultView(filmek).Filter = null;
        }

        private void Darab_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Filmek száma: " + filmek.Count
            );
        }

        private void Leghosszabb_Click(object sender, RoutedEventArgs e)
        {
            if (filmek.Count == 0)
            {
                MessageBox.Show("Nincsenek betöltött filmek!");
                return;
            }

            Film leghosszabb = filmek
                .OrderByDescending(f => f.Hossz)
                .First();

            MessageBox.Show(
                "Leghosszabb film: " + leghosszabb.Cim +
                "\nHossz: " + leghosszabb.Hossz + " perc"
            );
        }

        private void Atlag_Click(object sender, RoutedEventArgs e)
        {
            if (filmek.Count == 0)
            {
                MessageBox.Show("Nincsenek betöltött filmek!");
                return;
            }

            double atlag = filmek.Average(f => f.Ertekeles);

            MessageBox.Show(
                "Átlagos értékelés: " + atlag.ToString("0.00")
            );
        }

        private void SciFi_Click(object sender, RoutedEventArgs e)
        {
            var nezet = CollectionViewSource.GetDefaultView(filmek);

            nezet.Filter = obj =>
            {
                Film film = obj as Film;
                return film.Mufaj == "sci-fi";
            };
        }

        private void Cimek_Click(object sender, RoutedEventArgs e)
        {
            dgFilmek.Columns[0].Visibility = Visibility.Visible;
            dgFilmek.Columns[1].Visibility = Visibility.Collapsed;
            dgFilmek.Columns[2].Visibility = Visibility.Collapsed;
            dgFilmek.Columns[3].Visibility = Visibility.Collapsed;
        }

        private void Rendezes_Click(object sender, RoutedEventArgs e)
        {
            var nezet = CollectionViewSource.GetDefaultView(filmek);

            nezet.SortDescriptions.Clear();

            nezet.SortDescriptions.Add(
                new SortDescription("Cim", ListSortDirection.Ascending)
            );
        }

        private void dgFilmek_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (dgFilmek.SelectedItem is Film kivalasztott)
            {
                MessageBox.Show(
                    "Kiválasztott film: " + kivalasztott.Cim +
                    "\nÉrtékelés: " + kivalasztott.Ertekeles
                );
            }
        }
    }
}
