﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Data;

namespace Konyvek
{
    public partial class MainWindow : Window
    {
        ObservableCollection<Konyv> konyvek =
            new ObservableCollection<Konyv>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Betoltes_Click(object sender, RoutedEventArgs e)
        {
            konyvek.Clear();

            konyvek.Add(new Konyv
            {
                Cim = "1984",
                Szerzo = "George Orwell",
                Oldalszam = 328,
                Mufaj = "Sci-fi",
                Elerheto = true
            });

            konyvek.Add(new Konyv
            {
                Cim = "A szolgálólány meséje",
                Szerzo = "Margaret Atwood",
                Oldalszam = 311,
                Mufaj = "Disztópia",
                Elerheto = false
            });

            konyvek.Add(new Konyv
            {
                Cim = "Az ember tragédiája",
                Szerzo = "Madách Imre",
                Oldalszam = 250,
                Mufaj = "Dráma",
                Elerheto = true
            });

            konyvek.Add(new Konyv
            {
                Cim = "Dűne",
                Szerzo = "Frank Herbert",
                Oldalszam = 604,
                Mufaj = "Sci-fi",
                Elerheto = true
            });

            konyvek.Add(new Konyv
            {
                Cim = "Egri csillagok",
                Szerzo = "Gárdonyi Géza",
                Oldalszam = 552,
                Mufaj = "Történelmi",
                Elerheto = false
            });

            dgKonyvek.ItemsSource = konyvek;

            var nezet = CollectionViewSource.GetDefaultView(konyvek);

            nezet.Filter = null;
            nezet.SortDescriptions.Clear();

            foreach (var oszlop in dgKonyvek.Columns)
            {
                oszlop.Visibility = Visibility.Visible;
            }

            progressBar.Value = konyvek.Count;
        }

        private void Darab_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Összesen " + konyvek.Count + " könyv van."
            );
        }

        private void Leghosszabb_Click(object sender, RoutedEventArgs e)
        {
            if (konyvek.Count == 0)
            {
                MessageBox.Show("Nincsenek betöltött könyvek!");
                return;
            }

            Konyv leghosszabb = konyvek
                .OrderByDescending(k => k.Oldalszam)
                .First();

            MessageBox.Show(
                "Leghosszabb könyv: " + leghosszabb.Cim +
                "\nSzerző: " + leghosszabb.Szerzo +
                "\nOldalszám: " + leghosszabb.Oldalszam
            );
        }

        private void Atlag_Click(object sender, RoutedEventArgs e)
        {
            if (konyvek.Count == 0)
            {
                MessageBox.Show("Nincsenek betöltött könyvek!");
                return;
            }

            double atlag = konyvek.Average(k => k.Oldalszam);

            MessageBox.Show(
                "Átlagos oldalszám: " + atlag.ToString("0.00")
            );
        }

        private void Elerheto_Click(object sender, RoutedEventArgs e)
        {
            var nezet = CollectionViewSource.GetDefaultView(konyvek);

            nezet.Filter = obj =>
            {
                Konyv konyv = obj as Konyv;
                return konyv.Elerheto == true;
            };
        }

        private void Cimek_Click(object sender, RoutedEventArgs e)
        {
            dgKonyvek.Columns[0].Visibility = Visibility.Visible;
            dgKonyvek.Columns[1].Visibility = Visibility.Collapsed;
            dgKonyvek.Columns[2].Visibility = Visibility.Collapsed;
            dgKonyvek.Columns[3].Visibility = Visibility.Collapsed;
            dgKonyvek.Columns[4].Visibility = Visibility.Collapsed;
        }

        private void Rendezes_Click(object sender, RoutedEventArgs e)
        {
            var nezet = CollectionViewSource.GetDefaultView(konyvek);

            nezet.SortDescriptions.Clear();

            nezet.SortDescriptions.Add(
                new SortDescription(
                    "Szerzo",
                    ListSortDirection.Ascending
                )
            );
        }
    }
}
