﻿
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Data;

namespace Urhajok
{
    public partial class MainWindow : Window
    {
        ObservableCollection<Urhajo> urhajok =
            new ObservableCollection<Urhajo>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Betoltes_Click(object sender, RoutedEventArgs e)
        {
            urhajok.Clear();

            urhajok.Add(new Urhajo
            {
                Nev = "Falcon-9",
                Legenyseg = 7,
                MaxHatotav = 550000,
                UzemanyagSzint = 87,
                Gyarto = "SpaceX",
                KuldetesStatusz = "Sikeres",
                InditasEve = 2020
            });

            urhajok.Add(new Urhajo
            {
                Nev = "Orion-X1",
                Legenyseg = 4,
                MaxHatotav = 820000,
                UzemanyagSzint = 73,
                Gyarto = "NASA",
                KuldetesStatusz = "Folyamatban",
                InditasEve = 2023
            });

            urhajok.Add(new Urhajo
            {
                Nev = "StarRider",
                Legenyseg = 12,
                MaxHatotav = 910000,
                UzemanyagSzint = 66,
                Gyarto = "Boeing",
                KuldetesStatusz = "Sikeres",
                InditasEve = 2019
            });

            urhajok.Add(new Urhajo
            {
                Nev = "SolarWind",
                Legenyseg = 3,
                MaxHatotav = 300000,
                UzemanyagSzint = 92,
                Gyarto = "ESA",
                KuldetesStatusz = "Sikertelen",
                InditasEve = 2018
            });

            urhajok.Add(new Urhajo
            {
                Nev = "Galaxy-Cruiser",
                Legenyseg = 18,
                MaxHatotav = 1200000,
                UzemanyagSzint = 54,
                Gyarto = "Blue Origin",
                KuldetesStatusz = "Sikeres",
                InditasEve = 2022
            });

            urhajok.Add(new Urhajo
            {
                Nev = "Nova-Prime",
                Legenyseg = 10,
                MaxHatotav = 760000,
                UzemanyagSzint = 80,
                Gyarto = "Roscosmos",
                KuldetesStatusz = "Sikeres",
                InditasEve = 2017
            });

            urhajok.Add(new Urhajo
            {
                Nev = "Pioneer-VII",
                Legenyseg = 6,
                MaxHatotav = 640000,
                UzemanyagSzint = 70,
                Gyarto = "NASA",
                KuldetesStatusz = "Folyamatban",
                InditasEve = 2024
            });

            urhajok.Add(new Urhajo
            {
                Nev = "Titan-Hawk",
                Legenyseg = 14,
                MaxHatotav = 1050000,
                UzemanyagSzint = 48,
                Gyarto = "SpaceX",
                KuldetesStatusz = "Sikeres",
                InditasEve = 2021
            });

            urhajok.Add(new Urhajo
            {
                Nev = "CosmoJet",
                Legenyseg = 5,
                MaxHatotav = 430000,
                UzemanyagSzint = 93,
                Gyarto = "JAXA",
                KuldetesStatusz = "Sikertelen",
                InditasEve = 2016
            });

            urhajok.Add(new Urhajo
            {
                Nev = "Nebula-FX",
                Legenyseg = 11,
                MaxHatotav = 870000,
                UzemanyagSzint = 60,
                Gyarto = "ESA",
                KuldetesStatusz = "Sikeres",
                InditasEve = 2020
            });

            dgUrhajok.ItemsSource = urhajok;

            var nezet = CollectionViewSource.GetDefaultView(urhajok);

            nezet.Filter = null;
            nezet.GroupDescriptions.Clear();
            nezet.SortDescriptions.Clear();
        }

        private void Darab_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Összesen " + urhajok.Count + " űrhajó van."
            );
        }

        private void Legnagyobb_Click(object sender, RoutedEventArgs e)
        {
            if (urhajok.Count == 0)
            {
                MessageBox.Show("Nincsenek betöltött adatok!");
                return;
            }

            Urhajo legnagyobb = urhajok
                .OrderByDescending(u => u.MaxHatotav)
                .First();

            MessageBox.Show(
                "Űrhajó: " + legnagyobb.Nev +
                "\nGyártó: " + legnagyobb.Gyarto +
                "\nHatótáv: " + legnagyobb.MaxHatotav
            );
        }

        private void Sikeres_Click(object sender, RoutedEventArgs e)
        {
            var nezet = CollectionViewSource.GetDefaultView(urhajok);

            nezet.GroupDescriptions.Clear();

            nezet.Filter = obj =>
            {
                Urhajo urhajo = obj as Urhajo;
                return urhajo.KuldetesStatusz == "Sikeres";
            };
        }

        private void Atlag_Click(object sender, RoutedEventArgs e)
        {
            if (urhajok.Count == 0)
            {
                MessageBox.Show("Nincsenek betöltött adatok!");
                return;
            }

            double atlag = urhajok.Average(u => u.Legenyseg);

            MessageBox.Show(
                "Átlagos legénységszám: " + atlag.ToString("0.00")
            );
        }

        private void Csoportositas_Click(object sender, RoutedEventArgs e)
        {
            var nezet = CollectionViewSource.GetDefaultView(urhajok);

            nezet.Filter = null;
            nezet.GroupDescriptions.Clear();

            nezet.GroupDescriptions.Add(
                new PropertyGroupDescription("Gyarto")
            );
        }

        private void Kereses_Click(object sender, RoutedEventArgs e)
        {
            string keresettNev = txtKereses.Text.Trim();

            if (string.IsNullOrWhiteSpace(keresettNev))
            {
                MessageBox.Show("Írj be egy nevet a kereséshez!");
                return;
            }

            var nezet = CollectionViewSource.GetDefaultView(urhajok);

            nezet.GroupDescriptions.Clear();

            nezet.Filter = obj =>
            {
                Urhajo urhajo = obj as Urhajo;

                return urhajo.Nev.IndexOf(
                    keresettNev,
                    System.StringComparison.OrdinalIgnoreCase
                ) >= 0;
            };

            if (!nezet.Cast<Urhajo>().Any())
            {
                MessageBox.Show("Nem található ilyen űrhajó!");
            }
        }
    }
}
