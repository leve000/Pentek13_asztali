﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dolgozat
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Dolgozatok> dolgozatok = new List<Dolgozatok>();

        public MainWindow()
        {
            InitializeComponent();
            dGrid.ItemsSource = dolgozatok;
        }

        private void hozzaadas_Click(object sender, RoutedEventArgs e)
        {
            int eletkor = int.Parse(korBox.Text);
            int pontszam = int.Parse(szamBox.Text);
            dolgozatok.Add(new Dolgozatok(nevBox.Text, eletkor, pontszam));

            dGrid.Items.Refresh();

            nevBox.Text = "";
            korBox.Text = "";
            szamBox.Text = "";
        }
    }
}
