﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dolgozat
{
    public class Dolgozatok
    {
        public String Nev { get; set; }
        public int Eletkor { get; set; }
        public int Pontszam { get; set; }

        public Dolgozatok(string nev, int eletkor, int pontszam)
        {
            this.Nev = nev;
            this.Eletkor = eletkor;
            this.Pontszam = pontszam;
        }
    }
}
